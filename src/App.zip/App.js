import { Component } from 'react';
import './App.css';
import Footer from './component/Footer';
import Main from './component/Main';
import NavBar from './component/NavBar';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            repos: [],
            isLoaded: false,
        }
    }

    componentDidMount() {

        fetch("https://api.github.com/users/mhizsean/repos")
        .then(res => res.json())
        .then(json => {
            this.setState({
                isLoaded: true,
                repos: json,
            })
        });
    }
    
    render() {

        const { isLoaded, repos } = this.state;
        
        if (!isLoaded) {
            return <div>Loading</div>
        } 
        else {
            return (
                <div className="app">
                    <NavBar/>
                    <Main/>
                    <Footer/>
                </div>
            )
        }
    }
}


export default App;
